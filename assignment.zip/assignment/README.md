# Device Monitoring Dashboard

This project implements a real-time monitoring dashboard for remote devices.

## Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/Lakshmipathi98/-Assignment-Task-Python-Django-Developer.git
   cd device-monitoring-dashboard
