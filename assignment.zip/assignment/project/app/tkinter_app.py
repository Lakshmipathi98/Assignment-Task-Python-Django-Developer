import tkinter as tk
import json
import websocket

class DeviceDashboard(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Device Dashboard")
        self.geometry("400x300")

        self.device_listbox = tk.Listbox(self, width=40)
        self.device_listbox.pack(pady=10)

        # Connect to WebSocket server
        self.ws = websocket.WebSocketApp("ws://localhost:8000/ws/devices/",
                                         on_message=self.on_message,
                                         on_error=self.on_error,
                                         on_close=self.on_close)
        self.ws.on_open = self.on_open
        self.ws.run_forever()

    def on_open(self, ws):
        print("WebSocket connection opened")

    def on_message(self, ws, message):
        data = json.loads(message)
        device_info = f"ID: {data['id']}, Status: {data['status']}, Last Update: {data['last_update_time']}"
        self.device_listbox.insert(tk.END, device_info)

    def on_error(self, ws, error):
        print(f"WebSocket error: {error}")

    def on_close(self, ws, close_status_code, close_msg):
        print(f"WebSocket connection closed ({close_status_code}): {close_msg}")

if __name__ == "__main__":
    app = DeviceDashboard()
    app.mainloop()
